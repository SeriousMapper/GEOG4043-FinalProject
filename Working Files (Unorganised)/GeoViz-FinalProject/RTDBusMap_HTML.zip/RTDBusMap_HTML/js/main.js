
var mydata;
var map;
var geoJSON;

var info = L.control();

function jQueryAjax(){
    //define a variable to hold the data
    

    //basic jQuery ajax method
    $.ajax("data/GeoJSONSample3.json", {
        dataType: "json",
        success: function(response){
            mydata = response;
            console.log(mydata);
            renderMyMap();
        }
    });

    //check the data
    console.log(mydata);
};
function renderMyMap() {

    map = L.map('map').setView([39.7392, -104.9903], 9);

    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoiamFzb25tOTExIiwiYSI6ImNrdGFtcXpjbTFudGgydnEyaG5xYjM2MWoifQ.Q8hEN8vl6gm4dwg-joBdzg'
    }).addTo(map);

    console.log("I loaded", mydata)
    geoJSON = L.geoJson(mydata).addTo(map);
    console.log(geoJSON);

}

function style(feature) {
    return {
        weight: 2,
        opacity: 1,
        color: 'white',
        fillOpacity: 0.7,
        fillColor: 'black'
    };
}
function initialize() {
    jQueryAjax();
    
}
$(document).ready(initialize);